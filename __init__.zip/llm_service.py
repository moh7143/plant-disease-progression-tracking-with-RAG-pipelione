from typing import List
from openai import OpenAI

class OllamaLLM:
    def __init__(
        self,
        model_name="qwen2.5:1.5b",
        host="http://127.0.0.1:11434/v1"
    ):
        self.client = OpenAI(
            base_url=host,
            api_key="ollama"
        )
        self.model_name = model_name
        print(f"\nLoaded Ollama Model : {model_name}")

    def _format_context(self, contexts: List):
        if not contexts:
            return "No relevant documents found."
        formatted = []
        for i, doc in enumerate(contexts, start=1):
            content = doc.get("content", "").strip()
            metadata = doc.get("metadata", {})
            source = metadata.get("source_file", "Unknown")
            formatted.append(
                f"""
==============================
Document {i}
Source : {source}

{content}
==============================
"""
            )
        return "\n".join(formatted)

    def generate_answer(
        self,
        query: str,
        contexts: List
    ):
        formatted_context = self._format_context(contexts)
        prompt = f"""
You are an expert Agricultural Scientist.
You MUST answer ONLY from the supplied documents.
Do NOT make up information.If the answer is not contained in the supplied context,
reply exactly:"I could not find this information in the indexed documents."
If the disease exists in the documents, answer in this format and also you can skip one of 
the following if not there in chunks:
Scientific Name
Symptoms
Cause
Favorable Conditions
Treatment
Chemical Control
Organic Control
Prevention
==================================================
DOCUMENTS
{formatted_context}
==================================================
QUESTION
{query}
==================================================
ANSWER
"""
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a professional agricultural expert."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=400
            )
            answer = response.choices[0].message.content.strip()
            return answer
        except Exception as e:
            print(f"\nOllama Error : {e}")
            return "Sorry, I couldn't generate an answer."

    def test_connection(self):
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {
                        "role": "user",
                        "content": "Say Hello"
                    }
                ]
            )
            print("\nOllama Connected Successfully\n")
            print(response.choices[0].message.content)
            return True
        except Exception as e:
            print(e)
            return False

