import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

print(client.list_collections())

collection = client.get_collection("rag_docs")

print(collection.count())